package com.paulsattler.ampeliframe

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Build
//import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.webkit.*
//import android.support.annotation.RequiresApi
import android.widget.SeekBar
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.paulsattler.ampeliframe.R
//import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        /*  val wedData: String =  "<html><body><h1>Hello, Javatpoint!</h1></body></html>"
          val mimeType: String = "text/html"
          val utfType: String = "UTF-8"
          webView.loadData(wedData,mimeType,utfType)*/
//val myWebUrl: String = "192.168.188.24:80"
        //webView.loadUrl(myWebUrl)

        val webView = findViewById<WebView>(R.id.WebView)
        webView.settings.domStorageEnabled = true;
        webView.settings.loadsImagesAutomatically = true;
        webView.settings.javaScriptEnabled = true;
        webView.settings.setAppCacheEnabled(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            webView.settings.safeBrowsingEnabled = false;
            webView.settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW;
        }
        webView.settings.allowContentAccess = true;
        webView.settings.allowFileAccess = true;
        webView.settings.blockNetworkImage = false;
        webView.webViewClient = MyWebViewClient(this)
        webView.loadUrl("http://192.168.188.24/")
    }
    class MyWebViewClient internal constructor(private val activity: Activity) : WebViewClient() {

        @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val url: String = request?.url.toString();
            view?.loadUrl(url)
            return true
        }

        override fun shouldOverrideUrlLoading(webView: WebView, url: String): Boolean {
            webView.loadUrl(url)
            return true
        }
//Toast.makeText(activity, "Got Error! $error", Toast.LENGTH_SHORT).show()
    }
}
